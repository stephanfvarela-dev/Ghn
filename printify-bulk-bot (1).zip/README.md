<h1 align="center">🖨️ Printify Bulk Product Bot</h1>

<p align="center">
  <a href="https://github.com/stephanfvarela-dev/printify-bulk-bot/actions/workflows/publish.yml">
    <img src="https://github.com/stephanfvarela-dev/printify-bulk-bot/actions/workflows/publish.yml/badge.svg" alt="Auto Publish Workflow Status">
  </a>
  <img src="https://img.shields.io/badge/Auto%20Publish-%F0%9F%94%B4%20OFF-red?style=for-the-badge" alt="Auto Publish Status" />
</p>

<p align="center">
  <a href="https://www.python.org/"><img src="https://img.shields.io/badge/Python-3.9%2B-blue?logo=python&logoColor=white" alt="Python version"></a>
  <a href="https://developers.printify.com/"><img src="https://img.shields.io/badge/API-Printify-green?logo=printify" alt="Printify API"></a>
  <a href="https://www.shopify.com/"><img src="https://img.shields.io/badge/Integration-Shopify-black?logo=shopify" alt="Shopify"></a>
  <a href="https://github.com/stephanfvarela-dev/printify-bulk-bot/stargazers"><img src="https://img.shields.io/github/stars/stephanfvarela-dev/printify-bulk-bot?style=social" alt="GitHub stars"></a>
</p>

<p align="center">
  Automate bulk creation and publishing of Printify products for **FC Cabo Verde** — complete with your logo, Shopify visibility, and dynamic pricing.
</p>

---

## Store
- **Store name:** FC Cabo Verde  
- **Store URL:** https://fc-cabo-verde.printify.me

---

## Quick Start

1. Clone the project and upload to your GitHub repo (or unzip locally):
```bash
git clone https://github.com/stephanfvarela-dev/printify-bulk-bot.git
cd printify-bulk-bot
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Create `.env` from the example and fill in your Printify credentials:
```bash
cp .env.example .env
# then edit .env and set PRINTIFY_TOKEN and SHOP_ID
```

4. Create drafts (this uses the included `assets/logo.png`):
```bash
python create_drafts.py
```

5. Publish drafts (safe, rate-limited; can also be automated via GitHub Actions):
```bash
python publish_drafts.py
```

---

## Files included

- `create_drafts.py` — bulk-create Printify draft products (uses `assets/logo.png`)
- `publish_drafts.py` — publish drafts to Shopify with price markup and visibility options
- `.github/workflows/publish.yml` — GitHub Actions workflow to auto-publish every 30 minutes (toggle with `AUTO_PUBLISH` secret)
- `assets/logo.png` — your uploaded logo
- `drafts_created.csv` — generated after you run the create script
- `README.md`, `requirements.txt`, `.env.example`

---

If you'd like any filenames, default markup percentage, or blueprint IDs changed before I package the zip, tell me now and I will update the files accordingly.
