import os
import requests
from dotenv import load_dotenv

load_dotenv()

BASE = "https://api.printify.com/v1"
HEADERS = {"Authorization": f"Bearer {os.getenv('PRINTIFY_TOKEN')}"}

def test_connection():
    try:
        r = requests.get(f"{BASE}/shops.json", headers=HEADERS)
        if r.status_code != 200:
            print(f"❌ Error {r.status_code}: {r.text}")
            return
        shops = r.json()
        print("✅ Connection successful!")
        for shop in shops:
            print(f"- Shop name: {shop['title']}")
            print(f"  ID: {shop['id']}")
            print(f"  Sales channel: {shop['sales_channel']}")
            print()
    except Exception as e:
        print(f"⚠️ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()
