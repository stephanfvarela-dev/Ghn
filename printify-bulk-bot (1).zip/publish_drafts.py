import os, time, requests, pandas as pd
from dotenv import load_dotenv
load_dotenv()

BASE = "https://api.printify.com/v1"
HEADERS = {"Authorization": f"Bearer {os.getenv('PRINTIFY_TOKEN')}", "Content-Type": "application/json"}
SHOP_ID = os.getenv("SHOP_ID")
CSV_FILE = "drafts_created.csv"
PUBLISH_LIMIT = 200
WINDOW = 30 * 60

SHOPIFY_VISIBLE = True
PRICE_MARKUP = 25
COMPARE_AT = None

def publish(pid):
    url = f"{BASE}/shops/{SHOP_ID}/products/{pid}/publish.json"
    payload = {
        "title": True,
        "description": True,
        "images": True,
        "variants": True,
        "tags": True,
        "shopify_options": {
            "is_published": SHOPIFY_VISIBLE,
            "price_markup": PRICE_MARKUP,
            "compare_at_price": COMPARE_AT
        }
    }
    r = requests.post(url, headers=HEADERS, json=payload)
    return (r.status_code in (200,201)), r.text

def main():
    if not os.path.exists(CSV_FILE):
        print(f'No {CSV_FILE} found - nothing to publish.')
        return
    df = pd.read_csv(CSV_FILE)
    to_pub = df[df["status"]=="draft"].copy()
    window = []
    for _, row in to_pub.iterrows():
        now = time.time()
        window = [t for t in window if now - t < WINDOW]
        if len(window) >= PUBLISH_LIMIT:
            sleep_for = WINDOW - (now - window[0]) + 5
            print(f"[limit] sleeping {sleep_for/60:.1f} min...")
            time.sleep(sleep_for)
        ok, txt = publish(row["product_id"])
        window.append(time.time())
        status = "published" if ok else f"error:{txt}"
        print(f"[{status}] {row['product_id']}")
        df.loc[df["product_id"]==row["product_id"], "status"] = status
        df.to_csv(CSV_FILE, index=False)
        time.sleep(1)
    print("Publishing complete!")

if __name__ == "__main__":
    main()
