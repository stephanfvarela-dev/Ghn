import os, time, requests, pandas as pd
from dotenv import load_dotenv
load_dotenv()

BASE = "https://api.printify.com/v1"
HEADERS = {
    "Authorization": f"Bearer {os.getenv('PRINTIFY_TOKEN')}",
    "Content-Type": "application/json"
}
SHOP_ID = os.getenv("SHOP_ID")

# Use local logo included in the assets folder
LOGO_LOCAL_PATH = "assets/logo.png"
BLUEPRINTS = [1098]  # change to the blueprint IDs you want
PRODUCTS_PER_BLUEPRINT = 10  # default small number for testing; change to thousands as needed
OUTFILE = "drafts_created.csv"

def upload_logo(local_path):
    with open(local_path, "rb") as f:
        import base64
        encoded = base64.b64encode(f.read()).decode("ascii")
    payload = {"file_name": os.path.basename(local_path), "contents": encoded}
    r = requests.post(f"{BASE}/uploads/images.json", headers=HEADERS, json=payload)
    if r.status_code not in (200,201):
        raise SystemExit(f"Upload failed: {r.status_code} {r.text}")
    return r.json().get("preview_url") or r.json().get("url")

def choose_provider(bp):
    r = requests.get(f"{BASE}/catalog/blueprints/{bp}/print_providers.json", headers=HEADERS)
    r.raise_for_status()
    return r.json()[0]["id"]

def list_variants(bp, provider):
    r = requests.get(f"{BASE}/catalog/blueprints/{bp}/print_providers/{provider}/variants.json", headers=HEADERS)
    r.raise_for_status()
    return [v["id"] for v in r.json()]

def create_product(payload):
    r = requests.post(f"{BASE}/shops/{SHOP_ID}/products.json", headers=HEADERS, json=payload)
    if r.status_code in (200,201):
        return r.json()
    return {"error": r.text}

def main():
    logo_src = upload_logo(LOGO_LOCAL_PATH)
    rows = []
    for bp in BLUEPRINTS:
        prov = choose_provider(bp)
        variants = list_variants(bp, prov)
        for i in range(1, PRODUCTS_PER_BLUEPRINT + 1):
            payload = {
                "title": f"Auto {bp}-{i} - {os.path.basename(LOGO_LOCAL_PATH)}",
                "description": "Auto-generated draft by printify-bulk-bot",
                "blueprint_id": bp,
                "print_provider_id": prov,
                "print_areas": [{
                    "variant_ids": variants,
                    "placeholders": [{
                        "position": "front",
                        "images": [{"src": logo_src, "scale": 1.0, "x": 0.5, "y": 0.5}]
                    }]
                }],
                "tags": ["auto","logo"]
            }
            resp = create_product(payload)
            pid = resp.get("id")
            print(f"[draft] {pid}")
            rows.append({"product_id": pid, "blueprint": bp, "status": "draft"})
            time.sleep(0.2)
    pd.DataFrame(rows).to_csv(OUTFILE, index=False)
    print(f"Saved {len(rows)} drafts to {OUTFILE}")

if __name__ == "__main__":
    main()
